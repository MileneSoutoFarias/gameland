package gameland1;

public class configuraçoes {

    public final static int MAX_PARTICIPANTES = 30;
    public final static int N_CAMPOS_INFO = 4;
    public final static int N_JOGOS = 6;
    public final static int MAX_LINHAS_PAGINA = 3;
    public final static String SEPARADOR_DADOS_FICH = ";";
    public final static String BACKUP_FILE = "backup.txt";
    public final static int N_CAMPOS_RESULTADOS = 2;
    
}
